document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('regUsername').value;
    const password = document.getElementById('regPassword').value;

    localStorage.setItem('username', username);
    localStorage.setItem('password', password);
    alert('Registration successful!');
});

document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    const storedUsername = localStorage.getItem('username');
    const storedPassword = localStorage.getItem('password');

    if (username === storedUsername && password === storedPassword) {
        document.getElementById('securedPage').style.display = 'block';
        document.getElementById('container').style.display = 'Login Sucessfully!!!';
    } else {
        alert('Invalid credentials. Please try again.');
    }
});

document.getElementById('logout').addEventListener('click', function() {
    document.getElementById('securedPage').style.display = 'none';
    document.getElementById('container').style.display = 'block';
    document.getElementById('loginForm').reset();
});